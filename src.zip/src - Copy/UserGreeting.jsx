import React from 'react'

export default function UserGreeting() {
    return (
        <div>
            Hello User!
        </div>
    )
}
