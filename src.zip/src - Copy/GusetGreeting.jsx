import React from 'react'

export default function GusetGreeting() {
    return (
        <div>
            Hello Guest!
        </div>
    )
}
