import React from 'react'
import ReactDOM from 'react-dom'
import Conditional from './Conditional'


ReactDOM.render(<Conditional />, document.getElementById('root'))