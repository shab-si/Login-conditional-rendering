import React from 'react'

export default function Login(props) {
    return (
        <button onClick={props.handleClick}>log in</button>

    )
}
