import React from 'react'

export default function logout(props) {
    return (
        <button onClick={props.handleClick}>Loggout</button>
    )
}
